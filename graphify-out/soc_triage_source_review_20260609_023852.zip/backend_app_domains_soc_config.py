"""SOC domain configuration. All SOC-specific constants live here.

Constants are extracted from the existing service files — nothing is invented:
  factors        ← services/triage.py  _ALERT_FACTORS factor name list
  actions        ← services/agent.py   ACTION_* constants
                   services/situation.py evaluate_options() economics
  situation_types← services/situation.py SituationType enum
  policies       ← services/policy.py  POLICY_REGISTRY
  asymmetry_ratio← services/feedback.py get_reward_summary() asymmetric_ratio
  prompt_variants← services/evolver.py  PROMPT_STATS keys
  metrics_config ← routers/metrics.py   BusinessImpact values
"""

import os

import numpy as np
from gae.dk_estimator import CoordinateDescentEstimator
from gae.profile_scorer import LearningStrategy, ProfileScorer, build_profile_scorer, KernelType
from gae.shrinkage import FixedAlpha
from gae.two_phase import DecisionCountPolicy
from gae.calibration import CalibrationProfile

from app.domains.base import (
    DomainConfig, DomainAction, DomainFactor,
    DomainSituationType, DomainPolicy, PromptVariant,
)
from app.domains.soc.factors import (
    PrivilegedIdentityContextFactor, AssetCriticalityFactor, ThreatIntelEnrichmentFactor,
    PatternHistoryFactor, PatternHistoryFactorComputer, TimeAnomalyFactor, DeviceTrustFactor,
)
from dataclasses import dataclass, field
from typing import Dict, List


# ── v5.0 ProfileScorer Configuration ────────────────────────────────
# SOC categories (rows), scorer actions (cols), factors (depth)
# Factor order: [privileged_identity_context, asset_criticality, threat_intel_enrichment,
#                pattern_history, time_anomaly, device_trust]
# Action order: [escalate, investigate, suppress, monitor]
# Centroid values: what each action looks like for each category.
# Discriminative factors: >0.8 (strong signal) or <0.2 (strong absence)
# Non-discriminative factors: 0.3-0.6 (moderate)
# τ=0.1 (V3B validated ECE=0.036). Never use 0.25.
# ─────────────────────────────────────────────────────────────────────

# refer_to_analyst: 5th action (v5.5). Graduated dispatch — medium-confidence
# situations where the system is not confident enough to act autonomously.
# Activation requires confidence band + margin gate — see ReferralPolicy.
# Centroid values: LLM judge consensus (Opus-derived), March 2026.
SOC_ACTIONS = ["escalate", "investigate", "suppress", "monitor", "refer_to_analyst"]

# Phase 0b: 4-action scorer list.  refer_to_analyst is handled by the confidence
# gate in triage.py — not by the ProfileScorer centroid distance.
# Cross-experiment validation: A=4 static accuracy = 90.6% ± 0.6% (was 80.6% at A=5).
SCORER_ACTIONS = ["escalate", "investigate", "suppress", "monitor"]

# Single source of truth for the action-space split.
# Use these names everywhere in simulation, scoring, and triage paths.
SOC_SCORING_ACTIONS = SCORER_ACTIONS                               # A=4 scorer list
SOC_ROUTING_ACTIONS = list(SCORER_ACTIONS) + ["refer_to_analyst"]  # A=5 full list
SOC_N_ACT           = len(SCORER_ACTIONS)                          # 4

# Controls whether ProfileScorer.update() is called after verified outcomes.
# Default False (frozen scorer). Set True per-customer after shadow mode
# validates that learning improves outcomes.
LEARNING_ENABLED = False


def is_learning_enabled() -> bool:
    """Return whether live SOC centroid/DK learning is enabled."""
    raw = os.environ.get("SOC_LEARNING_ENABLED")
    if raw is None:
        return bool(LEARNING_ENABLED)
    return raw.strip().lower() in {"1", "true", "yes", "on"}

# Phase 1: graded reward computation + ledger. Defaults False until phase
# review passes and triage integration is explicitly implemented.
RL_REWARD_LEDGER_ENABLED = False

# Phase 2: Thompson sampling exploration proposals. Defaults False until
# explicit triage integration is reviewed and enabled.
RL_EXPLORATION_ENABLED = False

# Phase 4: temporary eta multiplier from graded reward. Defaults False until
# triage integration review passes.
RL_ETA_MODULATION_ENABLED = False

# Phase 4: read-only chain credit assignment. Defaults False until triage
# integration review passes.
RL_CHAIN_CREDIT_ENABLED = False

SOC_CATEGORIES = [
    "credential_access",
    "malware_execution",
    "lateral_movement",
    "data_exfiltration",
    "insider_threat",
    "cloud_infrastructure",
]

# Bootstrap category weights — reflects realistic SOC alert distribution.
# credential_access and lateral_movement are most frequent.
# cloud_infrastructure and malware_execution are least frequent.
# Weights must sum to 1.0.
DEFAULT_CATEGORY = "unclassified"

BOOTSTRAP_CATEGORY_WEIGHTS = {
    "credential_access":    0.30,
    "lateral_movement":     0.20,
    "data_exfiltration":    0.15,
    "insider_threat":       0.15,
    "cloud_infrastructure": 0.10,
    "malware_execution":     0.10,
}

# Shape: (N_CATEGORIES, N_ACTIONS, N_FACTORS) = 144 values at today's SOC size
# Action index: 0=escalate, 1=investigate, 2=suppress, 3=monitor  (SCORER_ACTIONS)
# Factor index: 0=privileged_identity_context, 1=asset_criticality, 2=threat_intel_enrichment,
#               3=pattern_history, 4=time_anomaly, 5=device_trust
SOC_FACTORS = [
    "privileged_identity_context",
    "asset_criticality",
    "threat_intel_enrichment",
    "pattern_history",
    "time_anomaly",
    "device_trust",
]

N_FACTORS = len(SOC_FACTORS)
N_CATEGORIES = len(SOC_CATEGORIES)
N_ACTIONS = len(SCORER_ACTIONS)

# Per-factor noise sigma — co-located with SOC_FACTORS so both stay in sync.
# When FEATURE-05B renames a factor, update the name here and sigma moves with it.
SOC_FACTOR_SIGMA = {
    "privileged_identity_context": 0.10,
    "asset_criticality":       0.12,
    "threat_intel_enrichment": 0.07,
    "pattern_history":         0.15,
    "time_anomaly":            0.20,
    "device_trust":            0.28,
}

# Bootstrap calibration parameters (GAE-BOOT-1)
# Used by gae_state.init_learning_state() on cold start or legacy checkpoint.
# Values validated against V3B ECE benchmark.
SOC_BOOTSTRAP_ROUNDS = 10
SOC_BOOTSTRAP_SAMPLES_PER_ACTION = 5
SOC_BOOTSTRAP_SIGMA = 0.08
SOC_BOOTSTRAP_CONVERGENCE_TOL = 0.01
SOC_BOOTSTRAP_SEED = 42

SOC_PROFILE_CENTROIDS = np.array([

  # ── Category 0: credential_access ──────────────────────────────
  # Axis-1: [escalate, investigate, suppress, monitor] — SCORER_ACTIONS only.
  # refer_to_analyst is a routing action handled by the confidence gate in
  # triage.py; it has no centroid geometry and is excluded from this tensor.
  [
    # escalate: travel anomaly + high asset + high threat_intel + low device_trust
    [0.75, 0.85, 0.80, 0.60, 0.65, 0.15],
    # investigate: moderate signals, some pattern history
    [0.60, 0.60, 0.55, 0.55, 0.50, 0.40],
    # suppress: low threat, normal hours, trusted device
    [0.30, 0.25, 0.15, 0.20, 0.25, 0.85],
    # monitor: moderate asset, low threat, normal pattern
    [0.20, 0.45, 0.25, 0.35, 0.35, 0.65],
  ],

  # ── Category 1: malware_execution (formerly threat_intel_match) ──
  [
    # escalate: high threat_intel + high asset_criticality
    [0.75, 0.80, 0.90, 0.55, 0.60, 0.20],
    # investigate: confirmed intel but lower asset risk
    [0.60, 0.55, 0.75, 0.50, 0.50, 0.40],
    # suppress: false positive intel, trusted device
    [0.30, 0.20, 0.20, 0.15, 0.20, 0.90],
    # monitor: low-confidence intel match
    [0.20, 0.40, 0.45, 0.30, 0.35, 0.70],
  ],

  # ── Category 2: lateral_movement ───────────────────────────────
  [
    # escalate: strong pattern history + high asset
    [0.75, 0.80, 0.70, 0.85, 0.70, 0.20],
    # investigate: some lateral signals, moderate asset
    [0.60, 0.60, 0.50, 0.65, 0.55, 0.40],
    # suppress: travel explains movement, trusted device
    [0.30, 0.25, 0.15, 0.20, 0.25, 0.80],
    # monitor: single hop, low asset, normal hours
    [0.20, 0.40, 0.30, 0.40, 0.35, 0.65],
  ],

  # ── Category 3: data_exfiltration ──────────────────────────────
  [
    # escalate: high asset + threat_intel + anomaly
    [0.75, 0.90, 0.75, 0.70, 0.80, 0.15],
    # investigate: high asset but unclear intent
    [0.60, 0.75, 0.50, 0.55, 0.60, 0.45],
    # suppress: authorized transfer, trusted device, normal hours
    [0.30, 0.30, 0.10, 0.15, 0.20, 0.90],
    # monitor: low-value asset, no threat intel
    [0.20, 0.40, 0.25, 0.30, 0.35, 0.70],
  ],

  # ── Category 4: insider_threat ─────────────────────────────────
  [
    # escalate: pattern history + time anomaly + low device_trust
    [0.75, 0.75, 0.65, 0.85, 0.80, 0.15],
    # investigate: behavioral signals, moderate confidence
    [0.60, 0.60, 0.50, 0.70, 0.60, 0.40],
    # suppress: explainable behavior, trusted device
    [0.30, 0.25, 0.15, 0.20, 0.20, 0.85],
    # monitor: weak signals, normal hours
    [0.20, 0.40, 0.30, 0.45, 0.35, 0.65],
  ],

  # ── Category 5: cloud_infrastructure ───────────────────────────
  [
    # escalate: high asset + threat_intel + time_anomaly
    [0.75, 0.85, 0.80, 0.60, 0.75, 0.20],
    # investigate: cloud anomaly, moderate signals
    [0.60, 0.65, 0.55, 0.50, 0.55, 0.45],
    # suppress: scheduled maintenance, trusted source
    [0.30, 0.25, 0.10, 0.15, 0.20, 0.90],
    # monitor: low-risk cloud activity
    [0.20, 0.45, 0.30, 0.30, 0.35, 0.70],
  ],

], dtype=np.float64).reshape(N_CATEGORIES, N_ACTIONS, N_FACTORS)
# Shape: (N_CATEGORIES, N_ACTIONS, N_FACTORS).
# Axis-1 order matches SCORER_ACTIONS: [escalate, investigate, suppress, monitor].

# SCORER_PROFILE_CENTROIDS is identical to SOC_PROFILE_CENTROIDS now that
# refer_to_analyst has been removed. Kept for backward-compat with call sites.
SCORER_PROFILE_CENTROIDS = SOC_PROFILE_CENTROIDS

# Auto-approve thresholds (Finding II: monitor excluded permanently)
# escalate:          100.0% accuracy in band — safe at 0.90
# investigate:        92.2% [90.8%, 93.5%] — passes 90% target
# suppress:           99.9% [99.7%, 100%] — exceptionally safe
# monitor:            86.0% — EXCLUDED, never reaches 99% at any threshold
# refer_to_analyst:   EXCLUDED — always routes to human_review by design (v5.5)
SOC_AUTO_APPROVE_THRESHOLDS = {
    "escalate":          0.90,
    "investigate":       0.90,
    "suppress":          0.90,
    "monitor":           None,   # excluded from auto-approve
    "refer_to_analyst":  None,   # excluded — explicit human dispatch (v5.5)
}

# Category confidence floors (Finding LL: credential_access warrants caution)
SOC_CATEGORY_CONFIDENCE_FLOORS = {
    "credential_access": 0.95,
}

# Elevated agent zone categories (62% + 34% of dangerous errors)
SOC_AGENT_ZONE_ELEVATED = {
    "malware_execution":    True,
    "cloud_infrastructure": True,
}

# All known alert_types mapped to their correct SOC category.
# Source: CORR-1 diagnostic, March 14, 2026. Updated BACKLOG-055 (April 2026).
# When adding new alert_types: add them HERE, not inline.
ALERT_TYPE_CATEGORY_MAP: dict = {
    # credential_access
    "anomalous_login":              "credential_access",
    "ambiguous_login_location":     "credential_access",
    "brute_force":                  "credential_access",
    "credential_stuffing":          "credential_access",
    "credential_access":            "credential_access",   # category name used as alert_type

    # malware_execution (formerly threat_intel_match)
    "threat_intel_match":           "malware_execution",   # alert_type kept; maps to new category name
    "phishing":                     "malware_execution",
    "malware_detection":            "malware_execution",
    "malware_execution":            "malware_execution",   # category name used as alert_type
    "c2_beacon":                    "malware_execution",

    # lateral_movement
    "privilege_escalation":         "lateral_movement",
    "internal_scan_ambiguous":      "lateral_movement",
    "lateral_movement":             "lateral_movement",    # category name used as alert_type

    # data_exfiltration
    "data_exfil":                   "data_exfiltration",
    "data_exfiltration":            "data_exfiltration",   # category name used as alert_type

    # insider_threat
    "insider_threat":               "insider_threat",
    "insider_threat_detected":      "insider_threat",
    "anomalous_behavior":           "insider_threat",

    # cloud_infrastructure
    "cloud_config":                      "cloud_infrastructure",
    "cloud_iam_privilege_escalation":    "cloud_infrastructure",
    "cloud_storage_public_exposure":     "cloud_infrastructure",
    "cloud_config_drift":                "cloud_infrastructure",
    "cloud_unused_resource_anomaly":     "cloud_infrastructure",
    "cloud_permission_change_review":    "cloud_infrastructure",
    "cloud_infrastructure":              "cloud_infrastructure",   # category name used as alert_type
}

UNCLASSIFIED_CATEGORY = "unclassified"


def resolve_alert_category(alert_type: str | None) -> str:
    """Map an alert_type string to its SOC category.

    Uses ALERT_TYPE_CATEGORY_MAP for explicit mapping.
    Returns ``unclassified`` with warning logging if unmapped.

    This function is the SINGLE routing point. Never resolve alert_type
    to category anywhere else in the codebase.
    """
    import logging
    _logger = logging.getLogger(__name__)

    normalized = (alert_type or "").strip()
    category = ALERT_TYPE_CATEGORY_MAP.get(normalized)
    if category is None:
        _logger.warning(
            "ROUTING_UNCLASSIFIED: alert_type=%r has no mapping in "
            "ALERT_TYPE_CATEGORY_MAP. Returning %r; this alert must not be "
            "scored against SOC centroids until mapped.",
            alert_type,
            UNCLASSIFIED_CATEGORY,
        )
        category = UNCLASSIFIED_CATEGORY
    return category


# Category → canonical ATT&CK pattern for outcome feedback
# These are the patterns seeded in the graph (seed_neo4j.py)
CATEGORY_PATTERN_MAP = {
    "credential_access":    "PAT-CRED-001",
    "malware_execution":    "PAT-THREAT-001",
    "lateral_movement":     "PAT-LATERAL-001",
    "data_exfiltration":    "PAT-EXFIL-001",
    "insider_threat":       "PAT-INSIDER-001",
    "cloud_infrastructure": "PAT-CLOUD-001",
    # Fallback for unknown categories
    "_default":             "PAT-UNKNOWN-001",
}


class SOCDomainConfig(DomainConfig):
    """Security Operations Center domain module."""

    # =========================================================================
    # Identity
    # =========================================================================

    @property
    def name(self) -> str:
        return "soc"

    @property
    def display_name(self) -> str:
        return "SOC Copilot"

    @property
    def trigger_entity(self) -> str:
        return "Alert"

    # =========================================================================
    # Factors
    # Source: services/triage.py — _ALERT_FACTORS["ALERT-7823"] name list +
    #         _build_threat_intel_factor() for the live factor at index 2.
    # Final factor order (from get_decision_factors docstring):
    #   [0] privileged_identity_context
    #   [1] asset_criticality
    #   [2] threat_intel_enrichment  (live Neo4j query)
    #   [3] time_anomaly
    #   [4] device_trust
    #   [5] pattern_history
    # =========================================================================

    @property
    def factors(self) -> List[DomainFactor]:
        return [
            DomainFactor(
                id="privileged_identity_context",
                label="Privileged Identity Context",
                description=(
                    "Privilege level, user risk, and session trust signals for the acting identity"
                ),
            ),
            DomainFactor(
                id="asset_criticality",
                label="Asset Criticality",
                description=(
                    "Target asset business impact and blast radius if action is wrong"
                ),
            ),
            DomainFactor(
                id="threat_intel_enrichment",
                label="Threat Intel Enrichment",
                description=(
                    "Live IOC match against threat intelligence feeds via Neo4j "
                    "ASSOCIATED_WITH relationship"
                ),
            ),
            DomainFactor(
                id="pattern_history",
                label="Pattern History",
                description=(
                    "Historical pattern match count and false positive rate "
                    "(e.g. PAT-TRAVEL-001: 127 cases)"
                ),
            ),
            DomainFactor(
                id="time_anomaly",
                label="Time Anomaly",
                description=(
                    "Login or activity time deviation from user baseline "
                    "(e.g. 3 AM home timezone)"
                ),
            ),
            DomainFactor(
                id="device_trust",
                label="Device Trust",
                description=(
                    "Device MDM enrollment, fingerprint match, and corporate posture score"
                ),
            ),
        ]

    # =========================================================================
    # Actions
    # Source: services/agent.py ACTION_* constants (5 actions total).
    # time_saved_min and cost_dollars: representative values from
    # services/situation.py evaluate_options() estimated_resolution_time and
    # estimated_analyst_cost fields.
    # =========================================================================

    @property
    def actions(self) -> List[DomainAction]:
        return [
            DomainAction(
                id="false_positive_close",
                label="Close as False Positive",
                time_saved_min=0.05,   # "3 seconds" — TRAVEL_LOGIN_ANOMALY option
                cost_dollars=0.0,
                risk_level="low",
            ),
            DomainAction(
                id="auto_remediate",
                label="Auto-Remediate",
                time_saved_min=0.13,   # "8 seconds" — KNOWN_PHISHING_CAMPAIGN option
                cost_dollars=0.0,
                risk_level="low",
            ),
            DomainAction(
                id="enrich_and_wait",
                label="Enrich and Wait",
                time_saved_min=20.0,   # "20 minutes" — VIP_AFTER_HOURS option
                cost_dollars=62.0,
                risk_level="low",
            ),
            DomainAction(
                id="escalate_tier2",
                label="Escalate to Tier 2",
                time_saved_min=45.0,   # "45 minutes" — TRAVEL_LOGIN_ANOMALY option
                cost_dollars=127.0,
                risk_level="none",
            ),
            DomainAction(
                id="escalate_incident",
                label="Escalate to Incident",
                time_saved_min=120.0,  # "2 hours" — MALWARE_ON_CRITICAL_ASSET option
                cost_dollars=310.0,
                risk_level="none",
            ),
        ]

    # =========================================================================
    # Situation types
    # Source: services/situation.py SituationType enum (6 members).
    # IDs: enum names (uppercase, as used in comparisons throughout the code).
    # Colors: chosen to match Tab 3 badge color coding (CLAUDE.md Wave 4).
    # =========================================================================

    @property
    def situation_types(self) -> List[DomainSituationType]:
        return [
            DomainSituationType(
                id="TRAVEL_LOGIN_ANOMALY",
                label="Travel Login Anomaly",
                description=(
                    "Anomalous login where user travel record and VPN location align — "
                    "likely a false positive"
                ),
                color="#3B82F6",  # blue
            ),
            DomainSituationType(
                id="KNOWN_PHISHING_CAMPAIGN",
                label="Known Phishing Campaign",
                description=(
                    "Email matches a known phishing campaign signature in the pattern library"
                ),
                color="#F97316",  # orange
            ),
            DomainSituationType(
                id="MALWARE_ON_CRITICAL_ASSET",
                label="Malware on Critical Asset",
                description=(
                    "Malware detected on a critical or production system — "
                    "immediate incident response required"
                ),
                color="#EF4444",  # red
            ),
            DomainSituationType(
                id="VIP_AFTER_HOURS",
                label="VIP After Hours",
                description=(
                    "Executive-level user activity outside normal business hours — "
                    "requires careful verification before escalation"
                ),
                color="#EAB308",  # yellow
            ),
            DomainSituationType(
                id="DATA_EXFIL_ATTEMPT",
                label="Data Exfiltration Attempt",
                description=(
                    "Unusual data transfer to an external destination above volume threshold — "
                    "forensics required"
                ),
                color="#DC2626",  # dark red
            ),
            DomainSituationType(
                id="UNKNOWN",
                label="Unknown",
                description=(
                    "Insufficient context for automated classification — "
                    "manual Tier 2 review recommended"
                ),
                color="#6B7280",  # gray
            ),
        ]

    # =========================================================================
    # Policies
    # Source: services/policy.py POLICY_REGISTRY (all 4 entries).
    # rule: maps to PolicyDefinition.description.
    # priority: matches PolicyDefinition.priority (1 = highest).
    # action_override: matches PolicyDefinition.action.
    # =========================================================================

    @property
    def policies(self) -> List[DomainPolicy]:
        return [
            DomainPolicy(
                id="POL-AUTO-CLOSE-TRAVEL",
                name="Auto-Close Travel Anomalies",
                rule=(
                    "Automatically close login anomaly alerts when user is traveling "
                    "and VPN matches travel destination"
                ),
                priority=3,
                action_override="false_positive_close",
            ),
            DomainPolicy(
                id="POL-ESCALATE-HIGH-RISK",
                name="Escalate High-Risk Users",
                rule=(
                    "Escalate all alerts for users with risk score above 0.80 "
                    "to Tier 2 analysts"
                ),
                priority=1,
                action_override="escalate_tier2",
            ),
            DomainPolicy(
                id="POL-REMEDIATE-KNOWN-PHISH",
                name="Auto-Remediate Known Phishing",
                rule=(
                    "Automatically remediate phishing alerts that match "
                    "known campaign signatures"
                ),
                priority=2,
                action_override="auto_remediate",
            ),
            DomainPolicy(
                id="POL-ISOLATE-CRITICAL-ASSETS",
                name="Isolate Critical Assets",
                rule=(
                    "Immediately isolate any malware detection "
                    "on critical infrastructure"
                ),
                priority=1,
                action_override="auto_remediate",
            ),
        ]

    # =========================================================================
    # Asymmetry ratio
    # Source: services/feedback.py get_reward_summary()
    #   "asymmetric_ratio": 20.0
    #   correct → +0.3, incorrect → -6.0  (6.0 / 0.3 = 20.0)
    # =========================================================================

    @property
    def asymmetry_ratio(self) -> float:
        return 20.0

    # =========================================================================
    # Prompt variants
    # Source: services/evolver.py PROMPT_STATS dict keys (4 variants).
    # category: derived from family prefix (TRAVEL_CONTEXT → anomalous_login,
    #           PHISHING_RESPONSE → phishing).
    # version: numeric suffix after _v.
    # =========================================================================

    @property
    def prompt_variants(self) -> List[PromptVariant]:
        return [
            PromptVariant(
                id="TRAVEL_CONTEXT_v1",
                category="anomalous_login",
                version=1,
                description="Base travel context prompt (71% success rate)",
            ),
            PromptVariant(
                id="TRAVEL_CONTEXT_v2",
                category="anomalous_login",
                version=2,
                description="Improved travel context prompt with VPN+calendar correlation (89% success rate)",
            ),
            PromptVariant(
                id="PHISHING_RESPONSE_v1",
                category="phishing",
                version=1,
                description="Base phishing response prompt — active (82% success rate)",
            ),
            PromptVariant(
                id="PHISHING_RESPONSE_v2",
                category="phishing",
                version=2,
                description="Experimental phishing response prompt — monitoring (80% success rate)",
            ),
        ]

    # =========================================================================
    # Metrics config
    # Source: routers/metrics.py BusinessImpact values in generate_compounding_data()
    # =========================================================================

    @property
    def metrics_config(self) -> Dict:
        return {
            "hrs_saved_monthly":       847,    # ~200 auto-closed alerts × 45 min manual review avoided
            "cost_avoided_quarterly":  127000, # analyst_hours × $50/hr × 3 months
            "mttr_reduction_pct":      75,     # MTTR improved from 12.4 min → 3.1 min
            "backlog_eliminated":      2400,   # alerts no longer waiting for human review
        }

    # =========================================================================
    # GAE factor computers — one FactorComputer per SOC factor
    # Reference: docs/soc_copilot_design_v1.md §14
    # =========================================================================

    def get_profile_centroids(self) -> np.ndarray:
        """
        Return profile centroids for ProfileScorer.
        Shape: (n_categories, n_actions, n_factors).
        τ=0.1 validated (V3B ECE=0.036).
        """
        return SOC_PROFILE_CENTROIDS.copy()

    def get_initial_centroids(self) -> np.ndarray:
        """Return the initial SOC profile centroids tensor."""
        return SOC_PROFILE_CENTROIDS.copy()

    def get_categories(self) -> list:
        """Return ordered category names."""
        return list(SOC_CATEGORIES)

    def get_category_index(self, category: str) -> int:
        """Return index for a category name. Raises ValueError if unknown."""
        try:
            return SOC_CATEGORIES.index(category)
        except ValueError:
            raise ValueError(
                f"Unknown SOC category: {category!r}. "
                f"Valid: {SOC_CATEGORIES}"
            )

    def get_auto_approve_threshold(self, action: str):
        """
        Return auto-approve confidence threshold for action.
        Returns None if action is excluded from auto-approve (monitor).
        """
        return SOC_AUTO_APPROVE_THRESHOLDS.get(action)

    def get_pattern_for_category(self, category: str) -> str:
        """
        Return the canonical ATT&CK pattern ID for an alert category.
        Used by process_outcome() to return category-appropriate patterns.
        Falls back to _default if category unknown.
        """
        return CATEGORY_PATTERN_MAP.get(category,
               CATEGORY_PATTERN_MAP["_default"])

    def build_profile_scorer(self) -> ProfileScorer:
        """
        Build a ProfileScorer from this domain config.
        Uses L2 kernel (EXP-E1 validated), τ=0.1 (V3B validated, default).

        Phase 0b: scorer uses SCORER_ACTIONS (A=4) and SCORER_PROFILE_CENTROIDS
        shaped as (N_CATEGORIES, N_ACTIONS, N_FACTORS). refer_to_analyst is handled by the confidence gate in
        triage.py, not by centroid proximity.  SOC_ACTIONS (A=5) is kept
        for the API response and NL templates.
        """
        return ProfileScorer(
            mu=SCORER_PROFILE_CENTROIDS.copy(),
            actions=list(SCORER_ACTIONS),
            kernel=KernelType.L2,
            categories=list(SOC_CATEGORIES),
            eta_override=0.01,       # P0 fix: attenuate override learning 5x
            auto_pause_on_amber=True,  # DRIFT-01: enable conservation RED/AMBER freeze
            learning_strategy=LearningStrategy(
                phase_policy=DecisionCountPolicy(n=200),
                dk_estimator=CoordinateDescentEstimator(),
                shrinkage_schedule=FixedAlpha(0.5),
            ),
        )

    @staticmethod
    def get_actions() -> List[str]:
        """
        Five SOC action names — full routing list (v5.5).
        For scoring use SCORER_ACTIONS (A=4); for NL/routing use this full list (A=5).
        """
        return list(SOC_ACTIONS)

    @staticmethod
    def get_factor_computers() -> List:
        """Return ordered list of SOC FactorComputer instances."""
        return [
            PrivilegedIdentityContextFactor(),
            AssetCriticalityFactor(),
            ThreatIntelEnrichmentFactor(),
            PatternHistoryFactorComputer(),
            TimeAnomalyFactor(),
            DeviceTrustFactor(),
        ]

    @staticmethod
    def get_campaign_config() -> dict:
        return {
            "correlation_window_hours": 24,
            "temporal_window_minutes": 60,
            "min_alerts_for_campaign": 2,
            "max_campaign_age_days": 30,
        }

    # =========================================================================
    # GAE weight matrix and temperature
    # Reference: docs/soc_copilot_design_v1.md §14
    # =========================================================================

    @staticmethod
    def get_initial_W():
        """Initial weight matrix (N_ACTIONS scorer actions × N_FACTORS factors). Security expert priors (v5.5).
        Row order matches SCORER_ACTIONS: [escalate, investigate, suppress, monitor].
        refer_to_analyst is a routing decision handled by the confidence gate — no W row.
        """
        import numpy as np
        return np.array([
            # privileged  asset  threat  pattern  time  device
            [ 0.75,   0.9,    0.9,    0.3,    0.4,   0.3],   # escalate
            [ 0.60,   0.5,    0.7,    0.5,    0.6,   0.5],   # investigate
            [-0.30,  -0.2,   -0.5,    0.7,   -0.3,  -0.2],   # suppress
            [ 0.20,   0.3,    0.4,    0.4,    0.3,   0.4],   # monitor
        ], dtype=np.float64).reshape(N_ACTIONS, N_FACTORS)

    # τ=0.1 (V3B validated, ECE=0.036). NEVER return 0.25.
    # Prior value of 0.25 was a pre-V3B default that was never updated after TD-030.
    # This affects simulation scoring — all prior simulation runs used wrong τ.
    @staticmethod
    def get_temperature() -> float:
        return 0.1

    # =========================================================================
    # Stubs — extracted in later prompts
    # =========================================================================

    def get_seed_queries(self) -> List[str]:
        # TODO: Extract from services/seed_neo4j.py in a later prompt
        return []

    def get_graph_query_templates(self) -> Dict[str, str]:
        # TODO: Extract from db/neo4j.py and routers/soc.py in a later prompt
        return {}

    def get_narration_templates(self) -> Dict[str, str]:
        # TODO: Extract from services/reasoning.py in a later prompt
        return {}


# Singleton instance used by domain_registry.py
soc_config = SOCDomainConfig()


# =============================================================================
# Block 9.5 — η change-rate cap (V-STABILITY F=8.14, UNCONDITIONAL)
# =============================================================================

# Maximum allowed per-coordinate centroid movement in any single update step.
# Mirrors MAX_ETA_DELTA in gae.profile_scorer (enforced there at the delta level).
# Source: V-STABILITY experiment F=8.14 — prevents runaway drift from large η × gradient.
MAX_ETA_DELTA: float = 0.005


# =============================================================================
# Block 7.2 — per-deployment θ_min formula
# =============================================================================

def compute_theta_min(alpha: float, V: float) -> float:
    """
    Minimum analyst quality (q̄) required for conservation law to hold.
    Formula: 23.53 / (alpha * V)
    Returns >1.0 for impossible deployments (V*alpha < 20/day).
    Validated: V=200, alpha=0.25 → 0.4706 ≈ 0.467 ✓
    Here alpha is analyst override rate, not learning rate or penalty ratio.

    Note: the GAE library already provides gae.calibration.derive_theta_min()
    (η × N_half² / T_max) for the learning-rate form of the same threshold.
    This function is the per-deployment throughput form used in P28 analysis.
    """
    if alpha <= 0 or V <= 0:
        return float('inf')
    return 23.53 / (alpha * V)


# =============================================================================
# Block 7.3 — P28 Phase 3 minimum decisions formula
# =============================================================================

def compute_phase3_minimum(V: float, alpha: float) -> int:
    """
    Minimum verified decisions before self-calibrating gates activate.
    Formula: max(1000, 20 * V * alpha)
    Validated: V=200, alpha=0.25 → max(1000, 1000) = 1000 ✓
    At V=50, alpha=0.25 → max(1000, 250) = 1000 (calendar constraint)
    At V=500, alpha=0.25 → max(1000, 2500) = 2500 (volume-driven)
    """
    decisions_per_day = V * alpha
    calendar_minimum = int(20 * decisions_per_day)
    return max(1000, calendar_minimum)


# =============================================================================
# Block 7.4 — Self-calibrating GateConfig
# =============================================================================

@dataclass
class GateConfig:
    """
    Deployment-specific gate configuration.
    Conservative defaults before N_min decisions.
    Calibrated values after N_min decisions.
    """
    n_decisions: int
    V: float = 200.0
    alpha: float = 0.25
    vol_std: float = 0.0
    per_analyst_precision: Dict[str, float] = field(default_factory=dict)

    @property
    def n_min(self) -> int:
        return compute_phase3_minimum(self.V, self.alpha)

    @property
    def calibrated(self) -> bool:
        return self.n_decisions >= self.n_min

    @property
    def spike_sigma(self) -> float:
        """Spike detection threshold. Conservative=5.0, Calibrated=3.0"""
        return 3.0 if self.calibrated else 5.0

    @property
    def eta_cap(self) -> float:
        """η change-rate cap. Conservative=2.0, Calibrated=deployment-specific"""
        if not self.calibrated:
            return 2.0
        if self.vol_std <= 0:
            return 1.5  # default calibrated cap
        return min(2.0, max(1.0, 1.5 + self.vol_std * 2))

    @property
    def eta_weights(self) -> Dict[str, float]:
        """
        Per-analyst η weights.
        Conservative: uniform (1.0 for all analysts).
        Calibrated: precision-weighted, only when each analyst
        has ≥10 decisions.
        """
        if not self.calibrated:
            return {a: 1.0 for a in self.per_analyst_precision}
        if not self.per_analyst_precision:
            return {}
        if not all(v >= 0 for v in self.per_analyst_precision.values()):
            return {a: 1.0 for a in self.per_analyst_precision}
        mean_prec = sum(self.per_analyst_precision.values()) / len(self.per_analyst_precision)
        if mean_prec <= 0:
            return {a: 1.0 for a in self.per_analyst_precision}
        return {
            analyst: min(1.5, max(0.5, prec / mean_prec))
            for analyst, prec in self.per_analyst_precision.items()
        }

    def summary(self) -> dict:
        return {
            "n_decisions": self.n_decisions,
            "n_min": self.n_min,
            "calibrated": self.calibrated,
            "spike_sigma": self.spike_sigma,
            "eta_cap": self.eta_cap,
            "eta_weights": self.eta_weights,
        }
